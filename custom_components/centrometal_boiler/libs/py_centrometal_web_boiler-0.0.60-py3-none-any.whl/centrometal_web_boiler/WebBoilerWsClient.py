# -*- coding: utf-8 -*-
"""
@author: Tihomir Heidelberg
"""

import logging
import asyncio
import stomper
import ssl
from centrometal_web_boiler.ws import ClientSocket

from centrometal_web_boiler.const import (
    WEB_BOILER_STOMP_LOGIN_USERNAME,
    WEB_BOILER_STOMP_LOGIN_PASSCODE,
    WEB_BOILER_STOMP_URL,
    WEB_BOILER_STOMP_DEVICE_TOPIC,
    WEB_BOILER_STOMP_NOTIFICATION_TOPIC,
)


class WebBoilerWsClient:

    def __init__(self, connected_callback, disconnected_callback, close_callback, data_callback):
        self.logger = logging.getLogger(__name__)
        self.connected_callback = connected_callback
        self.disconnected_callback = disconnected_callback
        self.close_callback = close_callback
        self.data_callback = data_callback
        self.client = ClientSocket()
        self.username = ""
        self.subscription_index = 0

        @self.client.on('connect')
        async def on_connect():
            self.logger.info(f"WebBoilerWsClient::on_connect ({self.username})")
            await self.client.send(stomper.connect(
                WEB_BOILER_STOMP_LOGIN_USERNAME,
                WEB_BOILER_STOMP_LOGIN_PASSCODE,
                "/",
                (90000, 60000),
            ))

        @self.client.on('message')
        async def on_message(message):
            data = message.data
            # Send newline keepalive for every frame received
            await self.client.send("\n")
            if data == "\n":  # Received keepalive frame, ignore it
                return
            frame = stomper.unpack_frame(data)
            if frame["cmd"] == "ERROR":
                await self.error_callback(self.client, frame)
                return
            if frame["cmd"] == "CONNECTED":
                self.logger.info(f"WebBoilerWsClient::on_message connected ({self.username})")
                await self.connected_callback(self.client, frame)
                return
            self.logger.debug(f"WebBoilerWsClient::on_message {frame} ({self.username})")
            await self.data_callback(self.client, frame)

        @self.client.on('disconnect')
        async def on_disconnect(code, reason):
            self.logger.error(f"WebBoilerWsClient::on_disconnect - {code} - {reason} ({self.username})")
            await self.disconnected_callback(self.client, code, reason)

        @self.client.on("close")
        async def on_close(code, reason):
            self.logger.info(f"WebBoilerWsClient::on_close close_status_code:{code} close_msg:{reason} ({self.username})")
            await self.disconnected_callback(self.client, code, reason)

    async def start(self, username: str) -> None:
        self.username = username
        self.logger.info(f"WebBoilerWsClient connecting... ({self.username})")
        # ssl.create_default_context() can do disk I/O (cert loading); run in executor
        # to avoid blocking the event loop. The HA integration also patches this,
        # but we guard here too for any non-HA usage.
        loop = asyncio.get_running_loop()
        ssl_ctx = await loop.run_in_executor(None, ssl.create_default_context)
        # _ClientSocket__main is name-mangled access to the private __main method
        self.client.loop.create_task(
            self.client._ClientSocket__main(WEB_BOILER_STOMP_URL, ssl=ssl_ctx)
        )

    async def close(self):
        if self.client.connection:
            await self.client.close()

    async def subscribe_to_notifications(self, ws):
        self.logger.info(f"WebBoilerWsClient::subscribe_to_notifications ({self.username})")
        topic = WEB_BOILER_STOMP_NOTIFICATION_TOPIC
        await self.client.send(stomper.subscribe(topic, "sub-0", "auto"))

    async def subscribe_to_installation(self, ws, device):
        device_type = device["type"]
        serial = device["serial"]
        self.logger.info(f"WebBoilerWsClient::subscribe_to_installation {serial} ({self.username})")
        topic = WEB_BOILER_STOMP_DEVICE_TOPIC + device_type + "." + serial
        self.subscription_index += 1
        await self.client.send(stomper.subscribe(topic, f"sub-{self.subscription_index}", "auto"))
