import typing


class ParameterConflict(Exception):
    def __init__(self, message: str, *, parameters: typing.List[str]):
        super().__init__(message)
        self.message = message
        # Fixed typo in original code: kept old attribute name as alias for backward compat
        self.parameters = parameters
        self.parameter = parameters  # retained for backward compatibility

    def __repr__(self) -> str:
        return f"{self.message}"

    def __str__(self) -> str:
        return self.__repr__()
