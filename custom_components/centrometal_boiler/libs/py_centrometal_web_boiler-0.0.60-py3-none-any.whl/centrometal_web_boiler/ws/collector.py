import typing
import datetime
import asyncio


class EventCollector:
    def __init__(self, websocket, time: float) -> None:
        self.__websocket = websocket
        self.__time = time

    async def collect(self, event: str, check: typing.Callable = None) -> typing.List[typing.Any]:
        collected = []
        # Fixed: deprecated naive UTC replaced with timezone-aware datetime
        start_time = datetime.datetime.now(datetime.timezone.utc)
        while (datetime.datetime.now(datetime.timezone.utc) - start_time).total_seconds() < self.__time:
            try:
                remaining = self.__time - (datetime.datetime.now(datetime.timezone.utc) - start_time).total_seconds()
                event_data = await self.__websocket.wait_for(event, check=check, timeout=remaining)
                collected.append(event_data)
            except asyncio.TimeoutError:
                pass
        return collected
